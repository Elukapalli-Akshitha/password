def is_safe_password(password):
    if len(password) < 8:
        return "Password is not safe due to insufficient length."
    if not any(char.islower() for char in password):
        return "Password is not safe, it needs at least one lowercase letter."
    if not any(char.isupper() for char in password):
        return "Password is not safe, it needs at least one uppercase letter."
    if not any(char.isdigit() for char in password):
        return "Password is not safe, it needs at least one digit."
    special_symbols = {'__', '@', '$'}
    if not any(char in special_symbols for char in password):
        return "Password is not safe, it needs at least one of the specified symbols ('__', '@', '$')."
    return "Password is safe."
password = input("Enter your password: ")
print(is_safe_password(password))